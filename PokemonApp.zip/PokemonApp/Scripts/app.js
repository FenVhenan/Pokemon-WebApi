﻿(function () {
    var app = angular.module("pokemonApp");

    var config = function ($routeProvider) {
        $routeProvider
            .when("/GetPokemon",
                { templateUrl: "values/GetPokemon" })
            .otherwise({ redirectTo: "/Index.cshtml" });
    };
    app.config(config);
}());