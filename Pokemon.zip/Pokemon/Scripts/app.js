﻿var app = angular.module('pokemonApp', []);

app.controller('pokemonController', function ($scope, $http) {
    $http.get("/values/GetPokemon")
        .then(function (response) {
            $scope.pokemons = response.data;
        });
});