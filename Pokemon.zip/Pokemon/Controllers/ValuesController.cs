﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Pokemon.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        //GET values/GetPokemon
        public async Task<JObject> HttpGet()
        {
            var Urlapi = "https://pokeapi.co/api/v2/";

            HttpClient client = new HttpClient();

            HttpResponseMessage response = await client.GetAsync(Urlapi);

            JObject pokemon = await response.Content.ReadAsAsync<JObject>();

            return pokemon;
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
